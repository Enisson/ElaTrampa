package com.squad53.elatrampa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElatrampaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElatrampaApplication.class, args);
	}

}
