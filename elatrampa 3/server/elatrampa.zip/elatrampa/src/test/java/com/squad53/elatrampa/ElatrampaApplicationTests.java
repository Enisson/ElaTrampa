package com.squad53.elatrampa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElatrampaApplicationTests {

	@Test
	void contextLoads() {
	}

}
